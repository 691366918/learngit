<?php
session_start();
header("Content-type:text/html;charset=utf-8");    //设置编码
$page=isset($_GET['page']) ?$_GET['page'] :1 ;//接收页码
$page=!empty($page) ? $page :1;
$F=$_GET['F'];
$_SESSION['F']=$F;

// 创建连接
$conn = mysqli_connect("localhost", "root", "root", "mybbs");
mysqli_set_charset($conn,'utf8'); //设定字符集
$table_name="topic";//查取表名设置
$perpage=50;//每页显示的数据个数
//最大页数和总记录数
$total_sql="select count(*) from $table_name where id='$F'";
$total_result =mysqli_query($conn,$total_sql);
$total_row=mysqli_fetch_row($total_result);
$total = $total_row[0];//获取最大页码数
$total_page = ceil($total/$perpage);//向上整数
//临界点
$page=$page>$total_page ? $total_page:$page;//当下一页数大于最大页数时的情况
//分页设置初始化
$start=($page-1)*$perpage;
$sql="select * from topic where F=$F order by id desc limit $start ,$perpage";
$que=mysqli_query($conn,$sql);
$sum=mysqli_num_rows($que);
?>
<?php
$sql1="select forum_name from forums where id='$F'";
$squ1=mysqli_query($conn,$sql1);
$row=mysqli_fetch_array($squ1);
$forum_name=$row['forum_name'];
echo "当前主题为：  $forum_name";
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>forum</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Forum---Thread-listing.css">
    <link rel="stylesheet" href="assets/css/Forum---Thread-listing1.css">
    <link rel="stylesheet" href="assets/css/Highlight-Clean.css">
    <link rel="stylesheet" href="assets/css/Navigation-with-Button.css">
    <link rel="stylesheet" href="assets/css/Pretty-Search-Form.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
   
    <div style="background-color:#ffffff;height:58px;">
        <nav class="navbar navbar-light navbar-expand-md bg-light navigation-clean-button" style="height:69px;">
            <div class="container-fluid"><a class="navbar-brand" href="#">Online Forums</a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse"
                    id="navcol-1">
                    <ul class="nav navbar-nav mr-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="#">First Item</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#">Second Item</a></li>
                        <li class="dropdown"><a class="dropdown-toggle nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false" href="#">Dropdown </a>
                            <div class="dropdown-menu" role="menu"><a class="dropdown-item" role="presentation" href="#">First Item</a><a class="dropdown-item" role="presentation" href="#">Second Item</a><a class="dropdown-item" role="presentation" href="#">Third Item</a></div>
                        </li>
                    </ul>
        <?php
			if(empty($_SESSION['username'])){            
                echo '<span class="navbar-text actions"> <a href="reg.html" class="login"><strong>注册</strong></a>
                <a class="btn btn-light action-button" role="button" href="login.html">登录</a></span>';
			}
			else{
                echo '<span class="navbar-text actions"> <a href="user.php" class="btn btn-light action-button" role="button"><strong>'.$_SESSION['username'].'</strong></a></span>';
            }
		?>            
            </div>
        </nav>
    </div>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-md-12" style="height:44px;">
                    <form class="search-form">
                        <div class="input-group">
                            <div class="input-group-prepend"><span class="input-group-text"><i class="fa fa-search"></i></span></div><input class="form-control" type="text" placeholder="I am looking for..">
                            <div class="input-group-append"><button class="btn btn-light" type="button">Search </button></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="highlight-clean" style="height:172px;">
        <div class="container" style="height:99px;">
            <div class="intro">
                <h2 class="text-center" style="height:8px;">Highlight</h2>
                <p class="text-center"><br>You cannot improve your past, but you can improve your future. Once time is wasted, life is wasted.<br><br></p>
            </div>
        </div>
    </div>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-md-8" style="background-color:#eef4f7;">
                    <ul class="thread-list">
                        <li class="thread"><span class="time">Apr 21</span><span class="title">Maecenas finibus est nec pretium molestie. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                        <li
                            class="thread"><span class="time">Apr 20</span><span class="title">Curabitur consectetur velit pharetra ex eleifend tempor. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                            <li
                                class="thread"><span class="time">Apr 20</span><span class="title">Fusce iaculis ligula at nisl mollis suscipit. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                                <li
                                    class="thread"><span class="time">Apr 18</span><span class="title">Pellentesque tempus augue id risus lacinia vehicula. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                                    <li
                                        class="thread"><span class="time">Apr 17</span><span class="title">Quisque lacinia massa non ex lobortis congue. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                                        <li
                                            class="thread"><span class="time">Apr 19</span><span class="title">Mauris quis elit vitae erat luctus sagittis non vel ex. </span><span class="icon"> <a href="javascript:void(0)" class="flag"></a></span></li>
                                            <li class="thread"><span class="time">Apr 17</span><span class="title">Nam dapibus urna vitae semper egestas. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                                            <li
                                                class="thread"><span class="time">Apr 15</span><span class="title">Sed sit amet ante malesuada, lacinia urna sed, faucibus sem. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                                                <li
                                                    class="thread"><span class="time">Mar 23</span><span class="title">Nullam et massa a velit laoreet porttitor et nec neque. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a></span></li>
                                                    <li class="thread"><span class="time">Mar 21</span><span class="title">Donec ut elit sodales, dignissim ligula at, posuere lacus. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                                                    <li
                                                        class="thread"><span class="time">Mar 2</span><span class="title">Nam in ligula vel nisl lobortis suscipit nec in lectus. </span><span class="icon"> <a href="javascript:void(0)" class="subscribe"></a><a href="javascript:void(0)" class="flag"></a></span></li>
                    </ul>
                </div>
                <div class="col-md-4"><a class="btn btn-light btn-block action-button" role="button" href="#" style="background-color:#66d7d7;"><font color="white">发帖</font></a>
                    <div style="height:26px;"></div>
                    <div><img class="img-thumbnail float-right" src="http://s9.sinaimg.cn/mw690/001ltMpWzy74pA9vav608&amp;690" style="width:350px;height:236px;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-basic">
        <footer>
            <div class="social"><a href="#"><i class="icon ion-social-instagram"></i></a><a href="#"><i class="icon ion-social-snapchat"></i></a><a href="#"><i class="icon ion-social-twitter"></i></a><a href="#"><i class="icon ion-social-facebook"></i></a></div>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="#">Home</a></li>
                <li class="list-inline-item"><a href="#">Services</a></li>
                <li class="list-inline-item"><a href="#">About</a></li>
                <li class="list-inline-item"><a href="#">Terms</a></li>
                <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
            </ul>
            <p class="copyright">Company Name © 2017</p>
        </footer>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>